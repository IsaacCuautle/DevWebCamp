<header class="dashboard__header">
    <div class="dashboard__header-grid">
        <a href="/">
            <h2 class="dashboard__logo">                
                &#60;DevWebCamp/>
            </h2>
        </a>

        <nav class="dashboard__nav">
            <form class="dashboard__form" method="POST" action="/logout">
                <input type="submit" value="Cerrar Sesion" class="dashboard__submit--logout">
            </form>
        </nav>
    </div>
</header>
